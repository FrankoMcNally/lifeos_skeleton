from lifeos import prime_map

def test_prime_map_import():
    # Check module loads correctly
    assert prime_map is not None
